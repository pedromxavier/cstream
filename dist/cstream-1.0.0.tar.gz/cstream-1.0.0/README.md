# cstream
## C++ Style Colorful output stream for Python with debug level capabilities.

Implements `Stream` object.

Default `stderr`, `stdwar` and `stdlog` instances are directed to standard error output. `stdout` is also available.